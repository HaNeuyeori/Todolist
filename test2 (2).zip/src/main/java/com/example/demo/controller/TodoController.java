package com.example.demo.controller;

import java.time.*;
import java.util.*;

import org.springframework.beans.factory.annotation.*;
import org.springframework.format.annotation.*;
import org.springframework.stereotype.*;
import org.springframework.ui.*;
import org.springframework.web.bind.annotation.*;

import com.example.demo.dao.*;
import com.example.demo.entity.*;

@Controller
public class TodoController {
	@Autowired
	private TodoDao todoDao;
	
	@GetMapping({"/","/list"})
	public String list(Model model) {
		List<Todo> todos = todoDao.findAll();
		model.addAttribute("todos", todos);
		return "list";
	}
	
	@GetMapping("/write")
	public String write() {
		return "write";
	}
	
	@PostMapping("/write")
	public String write(@RequestParam String job, @RequestParam @DateTimeFormat(pattern="yyyy-MM-dd") LocalDate deadline) {
		Todo todo = Todo.builder().job(job).deadline(deadline).finish(false).build();
		todoDao.save(todo);
		return "redirect:/list";
	}
	
	@PostMapping("/update")
	public String update(Integer tno) {
		todoDao.update(tno);
		return "redirect:/list";
	}
	
	@PostMapping("/delete")
	public String delete(Integer tno) {
		todoDao.delete(tno);
		return "redirect:/list";
	}
}
