package com.example.demo.entity;

import java.time.*;

import lombok.*;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Todo {
	private Long tno;
	private String job;
	private LocalDate deadline;
	private Boolean finish;
}
