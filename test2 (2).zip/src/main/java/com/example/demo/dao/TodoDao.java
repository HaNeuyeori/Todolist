package com.example.demo.dao;

import java.util.*;

import org.apache.ibatis.annotations.*;

import com.example.demo.entity.*;

@Mapper
public interface TodoDao {
	// insert, update, delete의 실행 결과는 변경된 행의 개수
	// 추가에 성공하면 1, 실패하면 0
	@Insert("insert into todos(tno, job, deadline, finish) values(todos_seq.nextval, #{job}, #{deadline}, 0)")
	public Integer save(Todo todo);
	
	// select는 1개를 읽는 경우 엔티티, 여러개를 읽는 경우 List<엔티티>를 리턴 
	@Select("select * from todos order by deadline asc")
	public List<Todo> findAll();
	
	// 찾아서 변경하려면 매개변수로 key가 필요
	// 변경에 성공하면 1이상의 값, 실패하면 0
	@Update("update todos set finish=abs(finish-1) where tno=#{tno}")
	public Integer update(Integer tno);
	
	// 찾아서 삭제하려면 매개변수로 key가 필요
	// 삭제에 성공하면 1이상의 값, 실패하면 0
	@Delete("delete todos where tno=#{tno}")
	public Integer delete(Integer tno);
}


