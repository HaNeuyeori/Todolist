package com.example.demo;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.boot.test.context.*;

import com.example.demo.dao.*;

@SpringBootTest
public class DaoTest {
	@Autowired
	public TodoDao todoDao;
	
	@Test
	public void initTest() {
		assertNotNull(todoDao);
		assertNull(todoDao);
		assertEquals(null, todoDao);
	}
}
